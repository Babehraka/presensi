<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbarsideleft = array(
		array(
			'path' => 'home', 
			'label' => 'Home', 
			'icon' => '<i class="material-icons ">home</i>'
		),
		
		array(
			'path' => 'hadir', 
			'label' => 'Hadir', 
			'icon' => '<i class="material-icons ">assignment</i>'
		),
		
		array(
			'path' => 'jenispresensi', 
			'label' => 'Jenispresensi', 
			'icon' => ''
		),
		
		array(
			'path' => 'kelas', 
			'label' => 'Kelas', 
			'icon' => ''
		),
		
		array(
			'path' => 'siswa', 
			'label' => 'Siswa', 
			'icon' => ''
		),
		
		array(
			'path' => 'xla', 
			'label' => 'X LA', 
			'icon' => '<i class="material-icons ">flash_on</i>'
		),
		
		array(
			'path' => 'xlb', 
			'label' => 'X LB', 
			'icon' => '<i class="material-icons ">flash_on</i>'
		),
		
		array(
			'path' => 'xtpa', 
			'label' => 'X TP A', 
			'icon' => '<i class="material-icons ">build</i>'
		),
		
		array(
			'path' => 'xtpb', 
			'label' => 'X TP B', 
			'icon' => '<i class="material-icons ">build</i>'
		),
		
		array(
			'path' => 'xtpc', 
			'label' => 'X TP C', 
			'icon' => '<i class="material-icons ">build</i>'
		),
		
		array(
			'path' => 'xtpd', 
			'label' => 'X TP D', 
			'icon' => '<i class="material-icons ">build</i>'
		),
		
		array(
			'path' => 'xtpe', 
			'label' => 'X TP E', 
			'icon' => '<i class="material-icons ">build</i>'
		),
		
		array(
			'path' => 'xtkra', 
			'label' => 'X TKR A', 
			'icon' => '<i class="material-icons ">directions_car</i>'
		),
		
		array(
			'path' => 'xtkrb', 
			'label' => 'X TKR B', 
			'icon' => '<i class="material-icons ">directions_car</i>'
		),
		
		array(
			'path' => 'xtkrc', 
			'label' => 'X TKR C', 
			'icon' => '<i class="material-icons ">directions_car</i>'
		),
		
		array(
			'path' => 'xtkrd', 
			'label' => 'X TKR D', 
			'icon' => '<i class="material-icons ">directions_car</i>'
		),
		
		array(
			'path' => 'xtkre', 
			'label' => 'X TKR E', 
			'icon' => '<i class="material-icons ">directions_car</i>'
		),
		
		array(
			'path' => 'xotra', 
			'label' => 'X OTR A', 
			'icon' => '<i class="material-icons ">airport_shuttle</i>'
		),
		
		array(
			'path' => 'xotrb', 
			'label' => 'X OTR B', 
			'icon' => '<i class="material-icons ">airport_shuttle</i>'
		),
		
		array(
			'path' => 'xdkv', 
			'label' => 'X DKV', 
			'icon' => '<i class="material-icons ">computer</i>'
		),
		
		array(
			'path' => 'xititl', 
			'label' => 'XI TITL', 
			'icon' => '<i class="material-icons ">flash_on</i>'
		),
		
		array(
			'path' => 'xitpa', 
			'label' => 'XI TP A', 
			'icon' => '<i class="material-icons ">build</i>'
		),
		
		array(
			'path' => 'xitpb', 
			'label' => 'XI TP B', 
			'icon' => '<i class="material-icons ">build</i>'
		),
		
		array(
			'path' => 'xitpc', 
			'label' => 'XI TP C', 
			'icon' => '<i class="material-icons ">build</i>'
		),
		
		array(
			'path' => 'xitpd', 
			'label' => 'XI TP D', 
			'icon' => '<i class="material-icons ">build</i>'
		),
		
		array(
			'path' => 'xitpe', 
			'label' => 'XI TP E', 
			'icon' => '<i class="material-icons ">build</i>'
		),
		
		array(
			'path' => 'xitkra', 
			'label' => 'XI TKR A', 
			'icon' => '<i class="material-icons ">directions_car</i>'
		),
		
		array(
			'path' => 'xitkrb', 
			'label' => 'XI TKR B', 
			'icon' => '<i class="material-icons ">directions_car</i>'
		),
		
		array(
			'path' => 'xitkrc', 
			'label' => 'XI TKR C', 
			'icon' => '<i class="material-icons ">directions_car</i>'
		),
		
		array(
			'path' => 'xitkrd', 
			'label' => 'XI TKR D', 
			'icon' => '<i class="material-icons ">directions_car</i>'
		),
		
		array(
			'path' => 'xitkre', 
			'label' => 'XI TKR E', 
			'icon' => '<i class="material-icons ">directions_car</i>'
		),
		
		array(
			'path' => 'xiotra', 
			'label' => 'XI OTR A', 
			'icon' => '<i class="material-icons ">airport_shuttle</i>'
		),
		
		array(
			'path' => 'xiotrb', 
			'label' => 'XI OTR B', 
			'icon' => '<i class="material-icons ">airport_shuttle</i>'
		),
		
		array(
			'path' => 'xidkv', 
			'label' => 'XI DKV', 
			'icon' => '<i class="material-icons ">computer</i>'
		),
		
		array(
			'path' => 'xiititl', 
			'label' => 'XII TITL', 
			'icon' => '<i class="material-icons ">flash_on</i>'
		),
		
		array(
			'path' => 'xiitpa', 
			'label' => 'XII TP A', 
			'icon' => '<i class="material-icons ">build</i>'
		),
		
		array(
			'path' => 'xiitpb', 
			'label' => 'XII TP B', 
			'icon' => '<i class="material-icons ">build</i>'
		),
		
		array(
			'path' => 'xiitpc', 
			'label' => 'XII TP C', 
			'icon' => '<i class="material-icons ">build</i>'
		),
		
		array(
			'path' => 'xiitpd', 
			'label' => 'XII TP D', 
			'icon' => '<i class="material-icons ">build</i>'
		),
		
		array(
			'path' => 'xiitpe', 
			'label' => 'XII TP E', 
			'icon' => '<i class="material-icons ">build</i>'
		),
		
		array(
			'path' => 'xiitkroa', 
			'label' => 'XII TKRO A', 
			'icon' => '<i class="material-icons ">directions_car</i>'
		),
		
		array(
			'path' => 'xiitkrob', 
			'label' => 'XII TKRO B', 
			'icon' => '<i class="material-icons ">directions_car</i>'
		),
		
		array(
			'path' => 'xiitkrod', 
			'label' => 'XII TKRO D', 
			'icon' => '<i class="material-icons ">directions_car</i>'
		),
		
		array(
			'path' => 'xiitkroc', 
			'label' => 'XII TKRO C', 
			'icon' => '<i class="material-icons ">directions_car</i>'
		),
		
		array(
			'path' => 'xiitkroe', 
			'label' => 'XII TKRO E', 
			'icon' => '<i class="material-icons ">directions_car</i>'
		),
		
		array(
			'path' => 'xiiotr', 
			'label' => 'XII OTR', 
			'icon' => '<i class="material-icons ">airport_shuttle</i>'
		),
		
		array(
			'path' => 'xiimm', 
			'label' => 'XII MM', 
			'icon' => '<i class="material-icons ">computer</i>'
		),
		
		array(
			'path' => 'user', 
			'label' => 'User', 
			'icon' => ''
		),
		
		array(
			'path' => 'role_permissions', 
			'label' => 'Role Permissions', 
			'icon' => ''
		),
		
		array(
			'path' => 'roles', 
			'label' => 'Roles', 
			'icon' => ''
		)
	);
		
	
	
			public static $user = array(
		array(
			"value" => "Administrator", 
			"label" => "Administrator", 
		),
		array(
			"value" => "User", 
			"label" => "User", 
		),
		array(
			"value" => "Rakanino", 
			"label" => "Rakanino", 
		),
		array(
			"value" => "Kuswoyo", 
			"label" => "Kuswoyo", 
		),
		array(
			"value" => "Desi", 
			"label" => "Desi", 
		),
		array(
			"value" => "Kusmiadi", 
			"label" => "Kusmiadi", 
		),
		array(
			"value" => "Tirta Ranantika", 
			"label" => "Tirta Ranantika", 
		),);
		
			public static $account_status = array(
		array(
			"value" => "Active", 
			"label" => "Active", 
		),
		array(
			"value" => "Pending", 
			"label" => "Pending", 
		),
		array(
			"value" => "Blocked", 
			"label" => "Blocked", 
		),);
		
}