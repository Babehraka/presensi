<?php 
$page_id = null;
$comp_model = new SharedController;
$current_page = $this->set_current_page_link();
?>
<div>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <h4 >Aplikasi Absensi Siswa SMK Wongsorejo</h4>
                </div>
                <div class="col-sm-3 comp-grid">
                    <?php $rec_count = $comp_model->getcount_hadir();  ?>
                    <a class="animated zoomIn record-count card bg-light text-dark"  href="<?php print_link("hadir/") ?>">
                        <div class="row">
                            <div class="col-2">
                                <i class="material-icons ">access_alarms</i>
                            </div>
                            <div class="col-10">
                                <div class="flex-column justify-content align-center">
                                    <div class="title">Hadir</div>
                                    <small class=""></small>
                                </div>
                            </div>
                            <h4 class="value"><strong><?php echo $rec_count; ?></strong></h4>
                        </div>
                    </a>
                </div>
                <div class="col-sm-3 comp-grid">
                    <?php $rec_count = $comp_model->getcount_siswa();  ?>
                    <a class="animated zoomIn record-count card bg-light text-dark"  href="<?php print_link("siswa/") ?>">
                        <div class="row">
                            <div class="col-2">
                                <i class="material-icons ">assignment_ind</i>
                            </div>
                            <div class="col-10">
                                <div class="flex-column justify-content align-center">
                                    <div class="title">Siswa</div>
                                    <small class=""></small>
                                </div>
                            </div>
                            <h4 class="value"><strong><?php echo $rec_count; ?></strong></h4>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
